package it.ispw.daniele.backpacker.exceptions;


public class EmptyFieldException extends Exception{

    public EmptyFieldException(String message){
        super(message);
    }
}
