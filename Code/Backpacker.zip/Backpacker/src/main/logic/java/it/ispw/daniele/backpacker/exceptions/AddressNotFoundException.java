package it.ispw.daniele.backpacker.exceptions;

public class AddressNotFoundException extends Exception{

    public AddressNotFoundException(String message){
        super(message);
    }

}
