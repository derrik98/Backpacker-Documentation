package it.ispw.daniele.backpacker.exceptions;


public class MonumentNotFoundException extends Exception {

    public MonumentNotFoundException(String message) {
        super(message);
    }
}
