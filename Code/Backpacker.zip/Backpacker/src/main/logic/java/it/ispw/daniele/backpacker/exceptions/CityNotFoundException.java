package it.ispw.daniele.backpacker.exceptions;

public class CityNotFoundException extends Exception {

    public CityNotFoundException(String message){
        super(message);
    }

}
