package it.ispw.daniele.backpacker.exceptions;

import java.io.Serial;

public class GenericException extends Exception{

    public GenericException(String message){
        super(message);
    }
}
