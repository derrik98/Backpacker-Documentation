package it.ispw.daniele.backpacker.exceptions;

public class GenericException extends Exception{

    public GenericException(String message){
        super(message);
    }
}
