package it.ispw.daniele.backpacker.exceptions;

public class DateException extends Exception{

    public DateException(String message) {
        super(message);
    }
}
