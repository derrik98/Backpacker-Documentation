package it.ispw.daniele.backpacker.utils;

public enum Roles {

    USER,
    TOURIST_GUIDE
}
