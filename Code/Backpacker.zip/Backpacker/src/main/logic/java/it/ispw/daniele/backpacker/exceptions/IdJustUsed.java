package it.ispw.daniele.backpacker.exceptions;

public class IdJustUsed extends Exception{

    public IdJustUsed(String message) {
        super(message);
    }
}
